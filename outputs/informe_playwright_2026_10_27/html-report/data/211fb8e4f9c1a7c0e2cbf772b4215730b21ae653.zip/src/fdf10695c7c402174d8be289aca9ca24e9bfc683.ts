import { expect, test } from '@playwright/test';
import { registerStudent } from './helpers';

for (const path of ['/perfil', '/progreso/', '/examen/']) {
  test(`protege ${path} cuando no hay sesión`, async ({ page }) => {
    await page.goto(path);
    await expect(page).toHaveURL(/\/login\?next=/);
    expect(new URL(page.url()).searchParams.get('next')).toBe(path);
    await expect(page.getByRole('heading', { name: 'Acceso de Estudiante' })).toBeVisible();
  });
}

test('rechaza una contraseña incorrecta', async ({ page }) => {
  await page.goto('/login');
  await page.getByLabel('Correo Institucional / Estudiante').fill('demo@pylevel.test');
  await page.getByLabel('Contraseña', { exact: true }).fill('PasswordIncorrecto!');
  await page.getByRole('button', { name: 'Iniciar Sesión', exact: true }).click();
  await expect(page.getByRole('alert')).toContainText('No se pudo iniciar sesión. Verifica tus credenciales');
  await expect(page).toHaveURL(/\/login$/);
});

test('registra una cuenta, conserva la sesión y permite salir e ingresar', async ({ page, context }) => {
  const student = await registerStudent(page);
  const cookie = (await context.cookies()).find(item => item.name === 'pylevel_session');
  expect(cookie).toMatchObject({ httpOnly: true, secure: true, sameSite: 'Lax' });
  await page.reload();
  await expect(page.getByLabel('Correo electrónico', { exact: true })).toHaveValue(student.email);
  await page.getByRole('button', { name: 'Cerrar sesión', exact: true }).click();
  await expect(page).toHaveURL(/\/login$/);
  await page.goto('/perfil');
  await expect(page).toHaveURL(/\/login\?next=/);
  await page.getByLabel('Correo Institucional / Estudiante').fill(student.email);
  await page.getByLabel('Contraseña', { exact: true }).fill(student.password);
  await page.getByRole('button', { name: 'Iniciar Sesión', exact: true }).click();
  await expect(page).toHaveURL(/\/perfil\/?$/);
  await expect(page.getByLabel('Nombre completo')).toHaveValue(student.name);
});

test('guarda los datos personales y los conserva al recargar', async ({ page }) => {
  await registerStudent(page);
  await page.getByLabel('Nombre completo').fill('Ana Playwright');
  await page.getByLabel('Ocupación', { exact: true }).fill('Desarrolladora');
  await page.getByLabel('Cumpleaños', { exact: true }).fill('2000-05-21');
  await page.getByRole('button', { name: /Guardar cambios/ }).click();
  await expect(page.getByRole('status').filter({ hasText: 'Tu perfil se guardó correctamente.' })).toBeVisible();
  await page.reload();
  await expect(page.getByLabel('Nombre completo')).toHaveValue('Ana Playwright');
  await expect(page.getByLabel('Ocupación', { exact: true })).toHaveValue('Desarrolladora');
  await expect(page.getByLabel('Cumpleaños', { exact: true })).toHaveValue('2000-05-21');
});

test('muestra el progreso inicial y feedback de una cuenta nueva', async ({ page }) => {
  await registerStudent(page);
  await page.goto('/progreso/');
  await expect(page.getByRole('heading', { name: 'Progreso y métricas', exact: true })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Tu primer ejercicio te espera' })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Tu progreso empieza con una práctica' })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Feedback para tu siguiente paso' })).toBeVisible();
  await page.getByRole('link', { name: 'Elegir un ejercicio →', exact: true }).click();
  await expect(page).toHaveURL(/\/ejercicios\/?$/);
});
