import { expect, test } from '@playwright/test';

test('permite saltar la introducción y navegar a ejercicios', async ({ page }) => {
  await page.goto('/?intro=1');
  await page.getByRole('button', { name: 'Saltar introduccion (Esc)' }).click();
  await expect(page.getByRole('heading', { level: 1, name: /Tu próxima/ })).toBeVisible();
  await page.getByRole('link', { name: /Dale forma a tu primera idea/ }).click();
  await expect(page).toHaveURL(/\/ejercicios\/?$/);
});

test('muestra el inicio en móvil sin desbordamiento horizontal', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/?intro=1');
  await page.getByRole('button', { name: 'Saltar introduccion (Esc)' }).click();
  await expect(page.getByRole('heading', { level: 1, name: /Tu próxima/ })).toBeVisible();
  await page.getByRole('heading', { name: /Con Python, construye/ }).scrollIntoViewIfNeeded();
  await expect(page.getByRole('heading', { name: /Con Python, construye/ })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});
